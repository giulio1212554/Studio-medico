/**
 * Lettura sicura delle variabili d'ambiente.
 * In browser sono disponibili solo quelle con prefisso VITE_.
 * Le chiavi secret restano solo lato server.
 */

function get(key: string, fallback = ""): string {
  if (typeof import.meta !== "undefined" && (import.meta as any).env) {
    return (import.meta as any).env[key] ?? fallback;
  }
  if (typeof process !== "undefined" && process.env) {
    return process.env[key] ?? fallback;
  }
  return fallback;
}

export const env = {
  // Stripe
  stripePublishableKey: get("VITE_STRIPE_PUBLISHABLE_KEY"),
  stripeSecretKey: get("STRIPE_SECRET_KEY"),
  stripeWebhookSecret: get("STRIPE_WEBHOOK_SECRET"),

  // Supabase
  supabaseUrl: get("VITE_SUPABASE_URL"),
  supabaseAnonKey: get("VITE_SUPABASE_ANON_KEY"),
  supabaseServiceKey: get("SUPABASE_SERVICE_ROLE_KEY"),

  // Email
  resendApiKey: get("RESEND_API_KEY"),
  emailFrom: get("EMAIL_FROM", "Ischia Rent <noreply@ischiarent.local>"),

  // Twilio
  twilioSid: get("TWILIO_ACCOUNT_SID"),
  twilioToken: get("TWILIO_AUTH_TOKEN"),
  twilioPhone: get("TWILIO_PHONE_NUMBER"),

  // Google
  googlePlacesKey: get("VITE_GOOGLE_PLACES_API_KEY"),
  googlePlaceId: get("GOOGLE_PLACE_ID"),

  // App
  appUrl: get("VITE_APP_URL", "http://localhost:3000"),
  isDev: get("NODE_ENV", "development") !== "production",
};

/** True se la chiave Stripe publishable è presente */
export const hasStripe = () => Boolean(env.stripePublishableKey && env.stripePublishableKey.startsWith("pk_"));

/** True se Supabase è configurato */
export const hasSupabase = () => Boolean(env.supabaseUrl && env.supabaseAnonKey);

/** True se Resend è configurato */
export const hasEmail = () => Boolean(env.resendApiKey && env.resendApiKey.startsWith("re_"));

/** True se Twilio è configurato */
export const hasSms = () => Boolean(env.twilioSid && env.twilioToken);

/** True se Google Places è configurato */
export const hasGooglePlaces = () => Boolean(env.googlePlacesKey && env.googlePlaceId);
