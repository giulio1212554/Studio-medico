/**
 * Client Supabase (browser).
 * Usato per:
 * - salvare prenotazioni
 * - upload documenti (patente, CI, foto check-in)
 * - leggere disponibilità
 *
 * Installazione: npm i @supabase/supabase-js
 * Finché le chiavi non ci sono, tutte le funzioni restituiscono mock / null.
 */

import { env, hasSupabase } from "./env";

let client: any = null;

export async function getSupabase() {
  if (!hasSupabase()) return null;
  if (client) return client;
  try {
    const { createClient } = await import("@supabase/supabase-js");
    client = createClient(env.supabaseUrl, env.supabaseAnonKey);
    return client;
  } catch {
    console.warn("[supabase] pacchetto non installato: npm i @supabase/supabase-js");
    return null;
  }
}

/** Upload file nel bucket "documents" */
export async function uploadDocument(
  file: File,
  path: string
): Promise<{ path: string; url: string } | null> {
  const sb = await getSupabase();
  if (!sb) {
    // Mock: restituisce object URL locale
    return { path, url: URL.createObjectURL(file) };
  }
  const { data, error } = await sb.storage.from("documents").upload(path, file, {
    upsert: true,
    contentType: file.type,
  });
  if (error) {
    console.error("[supabase] upload error", error);
    return null;
  }
  const { data: pub } = sb.storage.from("documents").getPublicUrl(data.path);
  return { path: data.path, url: pub.publicUrl };
}

/** Salva una prenotazione nella tabella "bookings" */
export async function saveBookingRemote(booking: Record<string, unknown>) {
  const sb = await getSupabase();
  if (!sb) return { ok: false, mock: true };
  const { data, error } = await sb.from("bookings").insert(booking).select().single();
  if (error) {
    console.error("[supabase] saveBooking", error);
    return { ok: false, error };
  }
  return { ok: true, data };
}

/** Controlla disponibilità di un mezzo tra due date */
export async function checkAvailability(
  vehicleId: string,
  start: string,
  end: string
): Promise<boolean> {
  const sb = await getSupabase();
  if (!sb) return true; // in mock tutto disponibile
  const { data, error } = await sb
    .from("bookings")
    .select("id")
    .eq("vehicle_id", vehicleId)
    .in("status", ["confirmed", "pending"])
    .lt("pickup", end)
    .gt("return", start);
  if (error) {
    console.error("[supabase] availability", error);
    return true;
  }
  return (data?.length ?? 0) === 0;
}

/**
 * Schema SQL da eseguire una volta in Supabase → SQL Editor:
 *
 * create table bookings (
 *   id uuid primary key default gen_random_uuid(),
 *   vehicle_id text not null,
 *   customer_name text,
 *   customer_email text,
 *   customer_phone text,
 *   pickup timestamptz,
 *   return timestamptz,
 *   extras jsonb default '[]',
 *   total numeric,
 *   deposit numeric,
 *   status text default 'pending',
 *   lang text default 'it',
 *   documents_path text,
 *   contract_path text,
 *   created_at timestamptz default now()
 * );
 *
 * -- Storage bucket "documents" (private)
 */
