import { createFileRoute } from "@tanstack/react-router";
import { DOCTORS, HOURS, CONTACT } from "@/lib/store";
import { Reveal, Stagger, StaggerItem } from "@/components/Reveal";
import { MapPin, Phone, Mail, Clock } from "lucide-react";

export const Route = createFileRoute("/chi-siamo")({
  component: ChiSiamoPage,
});

function ChiSiamoPage() {
  return (
    <div className="pt-16">
      {/* Hero */}
      <section className="bg-teal-light py-20">
        <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
          <Reveal>
            <h1 className="font-display text-4xl font-semibold tracking-tight sm:text-5xl">
              Chi siamo
            </h1>
            <p className="mt-4 max-w-2xl text-lg text-muted-foreground">
              Dal 2014 Studio Medico Aurelia offre medicina di qualità in un ambiente pensato per
              il comfort e la serenità del paziente. La tecnologia al servizio della cura.
            </p>
          </Reveal>
        </div>
      </section>

      {/* Storia */}
      <section className="py-20">
        <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <Reveal>
              <h2 className="font-display text-3xl font-semibold tracking-tight">La nostra storia</h2>
              <p className="mt-4 text-muted-foreground leading-relaxed">
                Nato dalla volontà di offrire un&apos;alternativa moderna agli studi tradizionali,
                Aurelia combina l&apos;esperienza clinica con strumenti digitali che eliminano le
                attese e la burocrazia. Prenotazioni online, ricette digitali, fatture automatiche:
                il paziente al centro, la segreteria alleggerita.
              </p>
              <p className="mt-4 text-muted-foreground leading-relaxed">
                Oggi siamo un team multidisciplinare che accompagna oltre mille pazienti nel percorso
                di salute, dalla prevenzione alle terapie croniche.
              </p>
            </Reveal>
            <Reveal delay={0.1}>
              <img
                src="https://images.unsplash.com/photo-1516549655169-df83a0774514?w=800&q=80"
                alt="Reception dello studio"
                className="rounded-2xl object-cover shadow-float aspect-[4/3]"
              />
            </Reveal>
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="bg-teal-light py-20">
        <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
          <Reveal>
            <h2 className="text-center font-display text-3xl font-semibold tracking-tight">
              Il team medico
            </h2>
          </Reveal>
          <Stagger className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {DOCTORS.map((d) => (
              <StaggerItem key={d.id}>
                <div className="overflow-hidden rounded-2xl border border-border/60 bg-card shadow-soft transition-shadow hover:shadow-float">
                  <img
                    src={d.image}
                    alt={d.name}
                    className="aspect-square w-full object-cover"
                    loading="lazy"
                  />
                  <div className="p-5">
                    <h3 className="font-display text-lg font-semibold">{d.name}</h3>
                    <p className="mt-0.5 text-sm font-medium text-primary">{d.specialty}</p>
                    <p className="mt-2 text-sm text-muted-foreground">{d.bio}</p>
                  </div>
                </div>
              </StaggerItem>
            ))}
          </Stagger>
        </div>
      </section>

      {/* Valori */}
      <section className="py-20">
        <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
          <Reveal>
            <h2 className="text-center font-display text-3xl font-semibold tracking-tight">
              I nostri valori
            </h2>
          </Reveal>
          <Stagger className="mt-12 grid gap-6 sm:grid-cols-3">
            {[
              {
                title: "Ascolto",
                desc: "Ogni paziente ha una storia unica. Dedichiamo tempo e attenzione a comprendere bisogni e aspettative.",
              },
              {
                title: "Trasparenza",
                desc: "Prezzi chiari, comunicazioni immediate, documenti sempre accessibili. Niente sorprese.",
              },
              {
                title: "Innovazione",
                desc: "Strumenti digitali per semplificare la vita del paziente e del medico, senza rinunciare al contatto umano.",
              },
            ].map((v) => (
              <StaggerItem key={v.title}>
                <div className="rounded-2xl border border-border/60 bg-card p-8 shadow-soft">
                  <h3 className="font-display text-xl font-semibold text-primary">{v.title}</h3>
                  <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{v.desc}</p>
                </div>
              </StaggerItem>
            ))}
          </Stagger>
        </div>
      </section>

      {/* Gallery struttura */}
      <section className="bg-teal-light py-20">
        <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
          <Reveal>
            <h2 className="text-center font-display text-3xl font-semibold tracking-tight">
              La struttura
            </h2>
          </Reveal>
          <Stagger className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                src: "https://images.unsplash.com/photo-1631217868264-e5b90bb7e630?w=700&q=80",
                alt: "Sala visite",
              },
              {
                src: "https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=700&q=80",
                alt: "Strumentazione",
              },
              {
                src: "https://images.unsplash.com/photo-1584820927498-cfe5211fd8bf?w=700&q=80",
                alt: "Camice e stetoscopio",
              },
            ].map((img) => (
              <StaggerItem key={img.alt}>
                <div className="overflow-hidden rounded-2xl">
                  <img
                    src={img.src}
                    alt={img.alt}
                    className="aspect-[4/3] w-full object-cover transition-transform duration-500 hover:scale-105"
                    loading="lazy"
                  />
                </div>
              </StaggerItem>
            ))}
          </Stagger>
        </div>
      </section>

      {/* Orari + Contatti + Mappa */}
      <section className="py-20">
        <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
          <div className="grid gap-10 lg:grid-cols-2">
            <Reveal>
              <h2 className="font-display text-3xl font-semibold tracking-tight">Orari e contatti</h2>
              <div className="mt-8 space-y-4">
                {HOURS.map((h) => (
                  <div key={h.day} className="flex items-center gap-3 text-sm">
                    <Clock className="size-4 text-primary shrink-0" strokeWidth={1.5} />
                    <span className="w-40 font-medium">{h.day}</span>
                    <span className="text-muted-foreground">{h.time}</span>
                  </div>
                ))}
              </div>
              <div className="mt-8 space-y-3 text-sm">
                <div className="flex items-center gap-3">
                  <MapPin className="size-4 text-primary shrink-0" strokeWidth={1.5} />
                  {CONTACT.address}
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="size-4 text-primary shrink-0" strokeWidth={1.5} />
                  <a href={`tel:${CONTACT.phone.replace(/\s/g, "")}`} className="hover:underline">
                    {CONTACT.phone}
                  </a>
                </div>
                <div className="flex items-center gap-3">
                  <Mail className="size-4 text-primary shrink-0" strokeWidth={1.5} />
                  <a href={`mailto:${CONTACT.email}`} className="hover:underline">
                    {CONTACT.email}
                  </a>
                </div>
              </div>
            </Reveal>
            <Reveal delay={0.1}>
              <div className="overflow-hidden rounded-2xl border border-border shadow-soft aspect-[4/3]">
                <iframe
                  title="Mappa Studio Aurelia"
                  src="https://maps.google.com/maps?q=Via+dei+Cedri+12+Roma&t=&z=15&ie=UTF8&iwloc=&output=embed"
                  className="h-full w-full border-0"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </Reveal>
          </div>
        </div>
      </section>
    </div>
  );
}
