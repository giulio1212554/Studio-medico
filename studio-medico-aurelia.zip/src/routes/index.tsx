import { createFileRoute, Link } from "@tanstack/react-router";
import { motion, useReducedMotion } from "framer-motion";
import {
  CalendarCheck,
  Mail,
  FileDown,
  Stethoscope,
  HeartPulse,
  Scan,
  Apple,
  TestTube,
  FileCheck,
  Pill,
  Video,
  ArrowRight,
  Star,
} from "lucide-react";
import { useEffect, useState, useRef } from "react";
import { SERVICES, REVIEWS, store } from "@/lib/store";
import { Reveal, Stagger, StaggerItem } from "@/components/Reveal";

export const Route = createFileRoute("/")({
  component: HomePage,
});

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Stethoscope,
  HeartPulse,
  Scan,
  Apple,
  TestTube,
  FileCheck,
  Pill,
  Video,
};

function AnimatedCounter({ value, suffix = "" }: { value: number; suffix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const reduce = useReducedMotion();

  useEffect(() => {
    if (reduce) {
      setCount(value);
      return;
    }
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          const duration = 1800;
          const start = performance.now();
          const step = (now: number) => {
            const p = Math.min((now - start) / duration, 1);
            const eased = 1 - Math.pow(1 - p, 3);
            setCount(Math.floor(eased * value));
            if (p < 1) requestAnimationFrame(step);
          };
          requestAnimationFrame(step);
          obs.disconnect();
        }
      },
      { threshold: 0.5 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [value, reduce]);

  return (
    <span ref={ref}>
      {count.toLocaleString("it-IT")}
      {suffix}
    </span>
  );
}

function HomePage() {
  const stats = store.stats();
  const reduce = useReducedMotion();

  return (
    <>
      {/* HERO */}
      <section className="relative min-h-[90vh] overflow-hidden">
        <motion.div
          className="absolute inset-0"
          style={{
            backgroundImage:
              "url(https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=1920&q=80)",
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
          initial={reduce ? false : { scale: 1.08 }}
          animate={reduce ? undefined : { scale: 1 }}
          transition={{ duration: 1.4, ease: [0.22, 1, 0.36, 1] }}
        />
        <div className="absolute inset-0 bg-gradient-to-br from-primary/70 via-primary/50 to-primary/80" />

        <div className="relative mx-auto flex min-h-[90vh] max-w-[1200px] flex-col justify-center px-4 pb-24 pt-28 sm:px-6">
          <motion.h1
            className="max-w-3xl font-display text-4xl font-semibold leading-[1.1] tracking-tight text-white sm:text-5xl md:text-6xl lg:text-7xl"
            initial={reduce ? false : { opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          >
            La cura, senza attese.
          </motion.h1>
          <motion.p
            className="mt-6 max-w-xl text-lg text-white/90 sm:text-xl"
            initial={reduce ? false : { opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
          >
            Prenota online, ricevi conferma immediata e scarica ricette e fatture dalla tua area
            paziente. Medicina di qualità in un ambiente calmo e luminoso.
          </motion.p>
          <motion.div
            className="mt-10 flex flex-wrap gap-4"
            initial={reduce ? false : { opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
          >
            <Link
              to="/prenota"
              className="inline-flex items-center gap-2 rounded-2xl bg-white px-6 py-3.5 text-sm font-semibold text-primary shadow-float transition-transform hover:scale-[1.02] active:scale-[0.98]"
            >
              Prenota una visita
              <ArrowRight className="size-4" />
            </Link>
            <Link
              to="/area-paziente"
              className="inline-flex items-center gap-2 rounded-2xl border-2 border-white/80 bg-white/10 px-6 py-3.5 text-sm font-semibold text-white backdrop-blur-sm transition-colors hover:bg-white/20"
            >
              Richiedi una ricetta
            </Link>
          </motion.div>

          {/* Glass card – next slot */}
          <motion.div
            className="absolute bottom-8 right-4 hidden rounded-2xl border border-white/30 bg-white/15 px-5 py-4 backdrop-blur-md sm:right-6 md:block"
            initial={reduce ? false : { opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
          >
            <p className="text-xs font-medium text-white/70">Primo orario libero oggi</p>
            <p className="mt-1 font-display text-2xl font-semibold text-white">16:30</p>
          </motion.div>
        </div>
      </section>

      {/* 3 STEPS */}
      <section className="bg-teal-light py-20">
        <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
          <Reveal>
            <h2 className="text-center font-display text-3xl font-semibold tracking-tight text-foreground sm:text-4xl">
              Come funziona
            </h2>
            <p className="mx-auto mt-3 max-w-lg text-center text-muted-foreground">
              Tre passi semplici per sostituire quasi tutto il lavoro della segreteria.
            </p>
          </Reveal>
          <Stagger className="mt-14 grid gap-8 sm:grid-cols-3">
            {[
              {
                icon: CalendarCheck,
                title: "Prenoti",
                desc: "Scegli servizio, data e orario libero in pochi click.",
              },
              {
                icon: Mail,
                title: "Ricevi conferma",
                desc: "Conferma automatica via email con tutti i dettagli.",
              },
              {
                icon: FileDown,
                title: "Scarichi i documenti",
                desc: "Ricette, fatture e referti sempre disponibili in area paziente.",
              },
            ].map((s) => (
              <StaggerItem key={s.title}>
                <div className="rounded-2xl border border-border/60 bg-card p-8 text-center shadow-soft transition-shadow hover:shadow-float">
                  <div className="mx-auto flex size-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                    <s.icon className="size-7" strokeWidth={1.5} />
                  </div>
                  <h3 className="mt-5 font-display text-xl font-semibold">{s.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{s.desc}</p>
                </div>
              </StaggerItem>
            ))}
          </Stagger>
        </div>
      </section>

      {/* SERVICES GRID */}
      <section className="py-20">
        <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
          <Reveal>
            <h2 className="text-center font-display text-3xl font-semibold tracking-tight sm:text-4xl">
              I nostri servizi
            </h2>
            <p className="mx-auto mt-3 max-w-lg text-center text-muted-foreground">
              Prestazioni specialistiche con prezzi trasparenti.
            </p>
          </Reveal>
          <Stagger className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {SERVICES.slice(0, 8).map((s) => {
              const Icon = iconMap[s.icon] || Stethoscope;
              return (
                <StaggerItem key={s.id}>
                  <div className="group flex h-full flex-col rounded-2xl border border-border/60 bg-card p-6 shadow-soft transition-all hover:-translate-y-1 hover:shadow-float">
                    <div className="flex size-11 items-center justify-center rounded-xl bg-secondary text-primary">
                      <Icon className="size-5" strokeWidth={1.5} />
                    </div>
                    <h3 className="mt-4 font-display text-lg font-semibold">{s.name}</h3>
                    <p className="mt-1.5 flex-1 text-sm text-muted-foreground line-clamp-2">
                      {s.description}
                    </p>
                    <div className="mt-4 flex items-center justify-between">
                      <span className="font-semibold text-primary">
                        {typeof s.price === "number" ? `€ ${s.price}` : s.price}
                      </span>
                      <Link
                        to="/prenota"
                        search={{ servizio: s.id }}
                        className="text-sm font-medium text-primary opacity-0 transition-opacity group-hover:opacity-100"
                      >
                        Prenota →
                      </Link>
                    </div>
                  </div>
                </StaggerItem>
              );
            })}
          </Stagger>
          <Reveal className="mt-10 text-center" delay={0.2}>
            <Link
              to="/servizi"
              className="inline-flex items-center gap-2 rounded-2xl border border-border bg-card px-5 py-2.5 text-sm font-medium text-foreground shadow-soft transition-colors hover:bg-secondary"
            >
              Vedi tutti i servizi
              <ArrowRight className="size-4" />
            </Link>
          </Reveal>
        </div>
      </section>

      {/* GALLERY */}
      <section className="bg-teal-light py-20">
        <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
          <Reveal>
            <h2 className="text-center font-display text-3xl font-semibold tracking-tight sm:text-4xl">
              Il nostro studio
            </h2>
          </Reveal>
          <Stagger className="mt-12 grid gap-4 sm:grid-cols-3">
            {[
              "https://images.unsplash.com/photo-1631217868264-e5b90bb7e630?w=800&q=80",
              "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&q=80",
              "https://images.unsplash.com/photo-1516549655169-df83a0774514?w=800&q=80",
            ].map((src, i) => (
              <StaggerItem key={i}>
                <div className="overflow-hidden rounded-2xl">
                  <img
                    src={src}
                    alt={
                      i === 0
                        ? "Sala visite luminosa"
                        : i === 1
                          ? "Medico con paziente"
                          : "Reception moderna"
                    }
                    className="aspect-[4/3] w-full object-cover transition-transform duration-500 hover:scale-105"
                    loading="lazy"
                  />
                </div>
              </StaggerItem>
            ))}
          </Stagger>
        </div>
      </section>

      {/* STATS */}
      <section className="py-20">
        <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
          <Stagger className="grid gap-8 sm:grid-cols-3">
            {[
              { value: stats.patients, label: "Pazienti seguiti", suffix: "+" },
              { value: stats.years, label: "Anni di esperienza", suffix: "" },
              { value: stats.doctors, label: "Medici specialisti", suffix: "" },
            ].map((s) => (
              <StaggerItem key={s.label}>
                <div className="rounded-2xl border border-border/60 bg-card p-8 text-center shadow-soft">
                  <p className="font-display text-4xl font-semibold text-primary sm:text-5xl">
                    <AnimatedCounter value={s.value} suffix={s.suffix} />
                  </p>
                  <p className="mt-2 text-sm text-muted-foreground">{s.label}</p>
                </div>
              </StaggerItem>
            ))}
          </Stagger>
        </div>
      </section>

      {/* REVIEWS */}
      <section className="bg-teal-light py-20">
        <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
          <Reveal>
            <h2 className="text-center font-display text-3xl font-semibold tracking-tight sm:text-4xl">
              Cosa dicono i pazienti
            </h2>
          </Reveal>
          <Stagger className="mt-12 grid gap-6 sm:grid-cols-3">
            {REVIEWS.map((r) => (
              <StaggerItem key={r.id}>
                <div className="flex h-full flex-col rounded-2xl border border-border/60 bg-card p-6 shadow-soft">
                  <div className="flex gap-0.5">
                    {Array.from({ length: r.rating }).map((_, i) => (
                      <Star key={i} className="size-4 fill-accent text-accent" />
                    ))}
                  </div>
                  <p className="mt-4 flex-1 text-sm leading-relaxed text-foreground/90">
                    &ldquo;{r.text}&rdquo;
                  </p>
                  <p className="mt-4 text-sm font-medium text-foreground">{r.name}</p>
                </div>
              </StaggerItem>
            ))}
          </Stagger>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="py-24">
        <div className="mx-auto max-w-[1200px] px-4 sm:px-6">
          <Reveal>
            <div className="rounded-3xl bg-primary px-8 py-16 text-center text-primary-foreground sm:px-16">
              <h2 className="font-display text-3xl font-semibold tracking-tight sm:text-4xl">
                Pronto a prenotare?
              </h2>
              <p className="mx-auto mt-4 max-w-md text-primary-foreground/85">
                Nessuna chiamata, nessuna attesa. Scegli il servizio e l&apos;orario che preferisci.
              </p>
              <Link
                to="/prenota"
                className="mt-8 inline-flex items-center gap-2 rounded-2xl bg-white px-7 py-3.5 text-sm font-semibold text-primary shadow-float transition-transform hover:scale-[1.02]"
              >
                Prenota ora
                <ArrowRight className="size-4" />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
